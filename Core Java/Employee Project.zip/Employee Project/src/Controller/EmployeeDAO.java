package Controller;

import java.util.ArrayList;
import model.*;

public class EmployeeDAO {
    private static ArrayList<Employee> employees = new ArrayList<>();

    static {
        employees.add(new HR(101, "Pallavi", 30000, 2000));
        employees.add(new HR(102, "Radhika", 65000, 3500));
        employees.add(new HR(103, "Priyanka", 21000, 2000));
        employees.add(new SalesManager(202, "Amruta", 45000, 12, 6700));
        employees.add(new Admin(301, "Aditya", 40000, 11000));
        employees.add(new Admin(302, "Rashi", 66000, 2300));
        employees.add(new Admin(303, "Aniket", 87000, 10000));
        employees.add(new Admin(304, "Durva", 35000, 11000));
    }

    public boolean addEmployee(Employee e) {
        return employees.add(e);
    }

    public Employee searchEmployeeById(int id) {
        for (Employee emp : employees) {
            if (emp.getId() == id) return emp;
        }
        return null;
    }

    public boolean updateEmployee(int id, double newSalary) {
        Employee emp = searchEmployeeById(id);
        if (emp != null) {
            emp.setSalary(newSalary);
            return true;
        }
        return false;
    }

    public boolean deleteEmployee(int id) {
        Employee emp = searchEmployeeById(id);
        if (emp != null) {
            employees.remove(emp);
            return true;
        }
        return false;
    }

    public ArrayList<Employee> getAllEmployee() {
        return employees;
    }
}
