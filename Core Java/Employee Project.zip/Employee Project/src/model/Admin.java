package model;

public class Admin extends Employee {
    double allowance;

    public Admin() {
        super();
    }

    public Admin(int id, String name, double salary, double allowance) {
        super(id, name, salary);
        this.allowance = allowance;
    }

    public double getAllowance() {
        return allowance;
    }

    @Override
    public double calculateSalary() {
        return getSalary() + allowance;
    }

    @Override
    public String toString() {
        return super.toString() + "\nAllowance: " + allowance;
    }
}
