package model;

public abstract class Employee {
    int id;
    String name;
    double salary;

    public Employee() {
        this.id = 0;
        this.name = "Not Given";
        this.salary = 10000;
    }

    public Employee(int id, String name, double salary) {
        this.id = id;
        this.name = name;
        this.salary = salary;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public abstract double calculateSalary();

    @Override
    public String toString() {
        return "ID: " + id + "\nName: " + name + "\nBase Salary: " + salary;
    }
}
