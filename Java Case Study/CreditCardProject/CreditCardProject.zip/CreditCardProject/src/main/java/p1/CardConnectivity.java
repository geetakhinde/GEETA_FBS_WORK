package p1;

public interface CardConnectivity {

	public boolean isValid(String v1,String v2,String v3,String v4);
}